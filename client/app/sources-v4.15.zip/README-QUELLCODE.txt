LoveChat / MaxiChat — Android-Quellcode (V4.15 / code 19)
=========================================================
Kotlin + Jetpack Compose, 100 % nativ, 0 % WebView.
minSdk 24 (Android 7) · targetSdk 36 · 186 Unit-Tests

Bauen:
  export JAVA_HOME=/pfad/zu/jdk17
  ./gradlew :app:testDebugUnitTest     # 186 Tests
  ./gradlew :app:assembleRelease       # braucht keystore.properties

Signatur (WICHTIG, sonst nicht update-fähig):
  keystore.properties im Projekt-Root:
    storeFile=/pfad/maxichat-release.jks
    storePassword=…
    keyAlias=maxichat
    keyPassword=…
  Ohne diese Datei baut Gradle eine unsignierte APK.
